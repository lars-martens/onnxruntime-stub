"""Stub implementation of the :mod:`onnxruntime` package for Vercel deployments."""

from __future__ import annotations

from typing import Any

__all__ = ["InferenceSession", "get_device"]


def _raise() -> None:
    raise RuntimeError(
        "onnxruntime is stubbed out in the Vercel deployment to keep the serverless bundle under the"
        " platform size limit. Install the real onnxruntime wheel in a non-serverless environment to"
        " access hardware accelerated inference."
    )


class InferenceSession:  # pragma: no cover - only used if downstream code mistakenly calls it
    """Placeholder session that raises to signal the stubbed environment."""

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        _raise()

    def run(self, *args: Any, **kwargs: Any) -> Any:
        _raise()


def get_device() -> str:
    """Return a sentinel device identifier."""

    return "CPU"
